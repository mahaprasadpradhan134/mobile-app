import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter GPS Locator',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  Position? _currentPosition;
  StreamSubscription<Position>? _positionStream;
  String _status = 'Idle';

  @override
  void initState() {
    super.initState();
    _checkPermissionsAndStart();
  }

  @override
  void dispose() {
    _positionStream?.cancel();
    super.dispose();
  }

  Future<void> _checkPermissionsAndStart() async {
    bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      setState(() => _status = 'Location services are disabled.');
      return;
    }

    LocationPermission permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        setState(() => _status = 'Location permission denied.');
        return;
      }
    }

    if (permission == LocationPermission.deniedForever) {
      setState(() => _status = 'Location permissions are permanently denied. Configure them from settings.');
      return;
    }

    setState(() => _status = 'Permissions granted. Starting location updates...');

    try {
      Position pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.best);
      setState(() {
        _currentPosition = pos;
        _status = 'Got current position.';
      });
    } catch (e) {
      setState(() => _status = 'Error getting current position: $e');
    }

    _positionStream = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.best,
        distanceFilter: 5,
      ),
    ).listen((Position position) {
      setState(() {
        _currentPosition = position;
        _status = 'Receiving updates...';
      });
    });
  }

  Future<void> _openInMaps() async {
    if (_currentPosition == null) return;
    final lat = _currentPosition!.latitude;
    final lon = _currentPosition!.longitude;

    final googleMapsUrl = Uri.parse('https://www.google.com/maps/search/?api=1&query=$lat,$lon');

    if (await canLaunchUrl(googleMapsUrl)) {
      await launchUrl(googleMapsUrl, mode: LaunchMode.externalApplication);
      return;
    }

    final geoUrl = Uri.parse('geo:$lat,$lon?q=$lat,$lon');
    if (await canLaunchUrl(geoUrl)) {
      await launchUrl(geoUrl);
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open maps.')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Flutter GPS Locator'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Status: $_status'),
            const SizedBox(height: 16),
            if (_currentPosition != null) ...[
              Text('Latitude: ${_currentPosition!.latitude}'),
              Text('Longitude: ${_currentPosition!.longitude}'),
              Text('Accuracy: ${_currentPosition!.accuracy} meters'),
              Text('Timestamp: ${_currentPosition!.timestamp ?? 'N/A'}'),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: _openInMaps,
                icon: const Icon(Icons.map),
                label: const Text('Open in Google Maps'),
              ),
            ] else ...[
              const Text('No location yet.'),
              const SizedBox(height: 12),
              ElevatedButton(
                onPressed: _checkPermissionsAndStart,
                child: const Text('Try get location now'),
              ),
            ],
            const Spacer(),
            const Text('Tip: Make sure location services are enabled and permissions granted.'),
          ],
        ),
      ),
    );
  }
}
